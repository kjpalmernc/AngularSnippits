# Workshop for this step

Make your own wrapper component. Use more elaborate HTML and CSS than
the simple example here; perhaps make an appearance more suitable for
your real projects.
