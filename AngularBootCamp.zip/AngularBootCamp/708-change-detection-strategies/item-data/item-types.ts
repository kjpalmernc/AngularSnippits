
export interface Item {
  name: string;
  description: string;
  completed: boolean;
}
