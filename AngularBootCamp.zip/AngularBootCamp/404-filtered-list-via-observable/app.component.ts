import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<employee-list></employee-list>'
})
export class AppComponent { }
