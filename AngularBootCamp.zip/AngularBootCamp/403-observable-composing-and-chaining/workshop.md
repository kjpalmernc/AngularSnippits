# Workshop for this step

There is no workshop for the specific piece of technology in the step,
but your instructor may use this context to make some more progress on
some example code and ask you to do the same on your workshop
application.
