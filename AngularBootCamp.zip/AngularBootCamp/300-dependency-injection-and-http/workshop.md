# Workshop for this step

* Delete the JavaScript array of video data from the video dashboard component.

* Use the HttpClient service to load the video data from one of these URLs:
  * StackBlitz users: 'https://api.angularbootcamp.com/videos'
  * Local development: 'http://localhost:8085/videos'

* Make sure you have the server running from inside the abc directory. The
  curriculum server is running a demo API server. For online students, the
  setup script created a proxy in the CLI project for you.
