import { Component } from '@angular/core';

@Component({
  selector: 'payroll-screen',
  templateUrl: './payroll-screen.component.html'
})
export class PayrollScreenComponent { }
