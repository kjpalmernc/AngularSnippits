import { Component } from '@angular/core';

@Component({
  selector: 'message-display',
  templateUrl: './message-display.component.html'
})
export class MessageDisplayComponent { }
