# Workshop for this step

* Add a route parameter that represents which video in the list is
  selected.
* Use that parameter to set the initially selected video.
* Update the list to navigate whenever a video is clicked using
  routerLink, rather than emitting an event.
