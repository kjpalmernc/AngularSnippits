import { Action, createFeatureSelector, createSelector } from '@ngrx/store';

import { ACK_ALL, DATA_RECEIVED, DataReceivedAction } from './state';

export const ACK_POSITION = 'ACK_POSITION';
export class AckPositionAction implements Action {
  type = ACK_POSITION;
  constructor(public payload: string) { }
}

const defaultPositionState: PositionState = {
  newPositions: [],
  currentPositions: []
};

export interface PositionState {
  newPositions: string[];
  currentPositions: string[];
}

export function positionReducer(
  state: PositionState = defaultPositionState,
  action: Action): PositionState {

  switch (action.type) {
    case ACK_POSITION:
      return ackPosition((action as AckPositionAction).payload, state);
    case ACK_ALL:
      // defensive copy of the data going into the store
      return {
        currentPositions: [...state.currentPositions, ...state.newPositions],
        newPositions: []
      };
    case DATA_RECEIVED:
      const a = (action as DataReceivedAction);
      return a.data.positions;
    default:
      return state;
  }
}

// defensive copy of the data going into the store
function ackPosition(position: string, currentState: PositionState): PositionState {
  const newPositions = currentState.newPositions.filter(x => x !== position);
  const currentPositions = [...currentState.currentPositions, position];
  return { newPositions, currentPositions };
}

// defensive copy of the data coming out of the store
// createSelector will memoize (cache) the result, meaning it will
// give the same object until the state changes
const getPositionState =
  createFeatureSelector<PositionState>('positions');

export const getNewPositions =
  createSelector(getPositionState, state => [...state.newPositions]);

export const getCurrentPositions =
  createSelector(getPositionState, state => [...state.currentPositions]);
